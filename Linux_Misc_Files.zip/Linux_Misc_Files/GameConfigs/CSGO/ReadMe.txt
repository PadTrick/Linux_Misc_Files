place the config.cfg and video.txt in "\Steam\userdata\<yourID>\730\local\cfg".
overwrite exiting files and check that config.cfg is write protected.
