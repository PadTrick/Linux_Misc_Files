# Linux_Misc_Files
Renamed the Repo to Linux_Misc_Files, because i use Archlinux for Gaming on my desktop, but started using a Stable OS in this case Debian 12 for my working pcs.

Backup of some Files, which i use after a fresh Archlinux or Debian Installation
Also 2 Lutris Installer Scripts are included, which arent on the official website. i just modified existing ones.
