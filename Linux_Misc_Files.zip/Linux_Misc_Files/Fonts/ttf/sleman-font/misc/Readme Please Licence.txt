ENGLISH


1. This Font License is (PERSONAL USE ONLY)
Which means you can only use this font for personal purposes that are not commercial (published)
Be it To Generate Profits / Profits, Both Material And Non-Material.
2. (PROHIBITED HARD) (DUPLICATING) and Distributing and Using This Font For Commercial Purposes.
Be it for Advertising, TV, Film, Video, Motion Graphic, YouTube, or for LOGO & Product Packaging (PHYSICAL OR NON-PHYSICAL (DIGITAL)
3. DOUBLE (PLAGIATE / COPY PASTE) and DISTRIBUTE / USE THESE Fonts For Commercial Use Whatever type and shape, NO LICENSES or WITHOUT BUYING LICENSE OF MY FIRST LETS FROM ME as CREATOR or HOLDER OF FONT COPYRIGHT, Will Be Used for Extended License Fees with a PRICE 100 times the Price of a STANDARD License,
For LICENSE INFORMATION what you will need, please contact me at:

Email: (yontypestudioco@gmail.com)



INDONESIA:


Berhati-hatilah sebelum Anda Menggunakan Font ini Untuk Keperluan Komersial 
Harap Luangkan Waktu Anda Untuk Membaca Ketentuan Lisensi Font yang  Ada 

Dengan Menginstal Font ini, Anda di anggap Mengeti dan Menyetujui Semua Syarat & ketentuan Penggunaan font ini

1. Lisensi Font ini adalah ( PERSONAL USE ONLY )
Yang Berarti Font ini hanya boleh anda Gunakan untuk keperluan Pribadi yang Sifatnya tidak Komersial ( Di Publikasikan ) 
Baik itu Untuk Menghasilkan Profit / Keuntungan, Baik Materil Maupun Non Matril.
Baik itu untuk Perorangan ( INDIVIDU ) ataupun ( Agensi Desain Grafis & Periklanan ( Advertising ) Percetakan dan Perusahaan/korporasi 

2. ( DILARANG KERAS ) Menggandakan ( MENDUPLIKASI ) dan Mendistribusikan dan Menggunakan Font ini Untuk keperluan Komersil.
Baik itu Untuk Iklan, Tv, Film, Video, Motion Graphic, YouTube, atau Untuk LOGO & Kemasan Product ( FISIK MAUPUN NON-FISIK ( DIGITAL ) dan dalam Media Apapun dengan Tujuan Menghasil kan Profit/Keuntungan, Materii maupun Non-Materi.

3. MENGGANDAKAN (PLAGIAT/MENG COPY PASTE) dan Mendistribusikan / Menggunakan Font ini Untuk Keperluan Komersil Apapun jenis dan bentuk nya, TANPA IZIN atau TANPA MEMBELI LISESNSI font terlebih dahulu dari SAYA sebagai PENCIPTA atau PEMEGANG HAK CIPTA FONT, Akan di Kenakan Biaya Extended License dengan HARGA 100 kali lipat dari Harga STANDARD License, Sesuai dengan Ketentuan yang telah diatur dalam UNDANG-UNDANG Nomer  28 Tahun 2014 Tentang Hak Cipta
yang berlaku di Negara Kesatuan Republik Indonesia

Untuk INFORMASI LISENSI apa yang akan anda perlukan, Silahkan Menghubungi Saya Di :

Email : (yontypestudioco@gmail.com ) 
Tlp/WhatsApp : ( 085930060853 )   