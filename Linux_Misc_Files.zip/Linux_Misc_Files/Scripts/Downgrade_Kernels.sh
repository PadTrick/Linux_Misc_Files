#!/bin/sh
sudo downgrade --ala-only linux linux-headers linux-lts linux-lts-headers linux-zen linux-zen-headers
echo "All Finished !!!"
