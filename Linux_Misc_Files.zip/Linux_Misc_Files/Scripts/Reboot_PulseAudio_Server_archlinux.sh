#!/bin/sh
systemctl --user restart pulseaudio.service
