#!/bin/sh
sudo downgrade --ala-only linux-zen linux-zen-headers
echo "All Finished !!!"
