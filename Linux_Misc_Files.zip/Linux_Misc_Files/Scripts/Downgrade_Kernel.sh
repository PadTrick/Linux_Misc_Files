#!/bin/sh
sudo downgrade --ala-only linux linux-headers
echo "All Finished !!!"
