#!/bin/sh
sudo downgrade --ala-only linux-lts linux-lts-headers
echo "All Finished !!!"
