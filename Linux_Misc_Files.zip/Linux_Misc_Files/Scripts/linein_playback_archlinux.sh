#!/bin/sh
pacmd load-module module-loopback latency_msec=5
echo "All Finished !!!"
