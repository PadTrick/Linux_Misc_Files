#!/bin/sh
sudo downgrade --ala-only nvidia-dkms nvidia-settings nvidia-utils lib32-nvidia-utils lib32-opencl-nvidia opencl-nvidia libxnvctrl
echo "All Finished !!!"
